// LOADER + REVEAL
window.addEventListener("load",()=>{
  setTimeout(()=>{
    document.getElementById("loader").style.display="none";
    reveal();
    loadFans();
  },1200);
});

function reveal(){
  document.querySelectorAll(".reveal").forEach(el=>{
    const r=el.getBoundingClientRect();
    if(r.top<window.innerHeight-100) el.classList.add("active");
  });
}
window.addEventListener("scroll",reveal);

// GOLD BUBBLES BACKGROUND
const canvas=document.getElementById("bgCanvas");
const ctx=canvas.getContext("2d");
canvas.width=innerWidth;canvas.height=innerHeight;

const bubbles=Array.from({length:40},()=>({
  x:Math.random()*canvas.width,
  y:Math.random()*canvas.height,
  r:Math.random()*3+1,
  dx:(Math.random()-0.5)*0.3,
  dy:(Math.random()-0.5)*0.3
}));

(function animate(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  bubbles.forEach(b=>{
    b.x+=b.dx;b.y+=b.dy;
    if(b.x<0||b.x>canvas.width)b.dx*=-1;
    if(b.y<0||b.y>canvas.height)b.dy*=-1;
    ctx.beginPath();
    ctx.arc(b.x,b.y,b.r,0,Math.PI*2);
    ctx.fillStyle="rgba(255,215,0,0.28)";
    ctx.fill();
  });
  requestAnimationFrame(animate);
})();

// CURSOR
const cursor=document.querySelector(".cursor");
const spotlight=document.querySelector(".spotlight");
window.addEventListener("mousemove",e=>{
  cursor.style.left=e.clientX+"px";
  cursor.style.top=e.clientY+"px";
  spotlight.style.left=e.clientX+"px";
  spotlight.style.top=e.clientY+"px";
});

// CLICK PARTICLES
document.addEventListener("click",e=>{
  const p=document.createElement("div");
  p.className="particle";
  p.style.left=e.clientX+"px";
  p.style.top=e.clientY+"px";
  document.body.appendChild(p);
  p.animate([{transform:"scale(1)",opacity:1},{transform:"scale(6)",opacity:0}],{duration:700});
  setTimeout(()=>p.remove(),700);
});

// FAN ZONE (FETCH & DISPLAY)
async function addFan(){
  const input=document.getElementById("fanInput");
  if(!input.value.trim())return;
  await fetch("/fans",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:input.value})});
  input.value="";
  loadFans();
}

async function loadFans(){
  const res=await fetch("/fans");
  const fans=await res.json();
  const list=document.getElementById("fanList");
  list.innerHTML="";
  fans.forEach(f=>{
    const div=document.createElement("div");
    div.className="fan-card";
    div.innerHTML=`<p>${f.message}</p><small>${new Date(f.createdAt).toLocaleString()}</small>`;
    list.appendChild(div);
  });
}

// COUNTERS
document.querySelectorAll(".count").forEach(c=>{
  const t=+c.dataset.target;let v=0;
  const s=t/100;
  const it=setInterval(()=>{
    v+=s;
    if(v>=t){c.innerText=t;clearInterval(it)}
    else c.innerText=Math.floor(v);
  },20);
});

// CHART
new Chart(document.getElementById("goalsChart"),{
  type:"line",
  data:{
    labels:["2005","2010","2015","2020","2024"],
    datasets:[{label:"Career Goals",data:[80,300,550,750,870],borderColor:"gold",tension:.4}]
  },
  options:{
    plugins:{legend:{labels:{color:"white"}}},
    scales:{x:{ticks:{color:"white"}},y:{ticks:{color:"white"}}}
  }
});
